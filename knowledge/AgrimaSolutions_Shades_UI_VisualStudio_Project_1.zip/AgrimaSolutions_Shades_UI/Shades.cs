using System;
using Crestron.RAD.Common.Attributes.Programming;
using Crestron.RAD.Common.Enums;
using Crestron.RAD.Common.Interfaces;
using Crestron.RAD.DeviceTypes.ExtensionDevice;
using Crestron.SimplSharp;

namespace UI_Tiles_AgrimaSolutions_Shades_Generic_UI_Cloud_Connected
{
    /// <summary>
    /// Agrima Solutions - Shades Generic UI (Cloud Connected).
    /// Extension device driver for up to 10 independently controlled shades/curtains.
    ///
    /// This class is the entry point Crestron Home instantiates - its fully qualified
    /// name ("UI_Tiles_AgrimaSolutions_Shades_Generic_UI_Cloud_Connected.Shades") must match the "className" field in the
    /// .dat manifest exactly. It owns the UI-facing properties/commands/events and
    /// delegates the actual communication work to ShadesProtocol -> ShadesTransport.
    ///
    /// BUILD NOTE: base class / interface member signatures below (AExtensionDevice,
    /// ICloudConnected, Create_Device_Definition, SetDriverPropertyValue, ErrorLog,
    /// DoCommand) are written to match the architecture confirmed from the reference
    /// package this replaces, but the *exact* signatures depend on the Crestron.RAD.*
    /// SDK NuGet package versions restored in this project. If the compiler flags a
    /// mismatch here, that's expected on a first build - fix the signature to match
    /// IntelliSense/compiler guidance; the logic inside each method does not need to
    /// change.
    /// </summary>
    public class Shades : AExtensionDevice, ICloudConnected
    {
        private readonly ShadesProtocol _protocol;
        private bool _isConnected;

        public Shades()
        {
            _protocol = new ShadesProtocol(this);
        }

        // ---------------------------------------------------------------
        // ICloudConnected
        // ---------------------------------------------------------------

        public bool IsConnected
        {
            get => _isConnected;
            set => _isConnected = value;
        }

        public void Initialize()
        {
            _protocol.Initialize();
        }

        // ---------------------------------------------------------------
        // Device / property definition
        // ---------------------------------------------------------------

        protected override void Create_Device_Definition()
        {
            base.Create_Device_Definition();

            foreach (var n in ShadesConstants.AllShadeNumbers())
            {
                RegisterProperty(ShadesConstants.NameProperty(n), DevicePropertyType.String, string.Empty);
                RegisterProperty(ShadesConstants.VisibleProperty(n), DevicePropertyType.Boolean, false);
            }
        }

        /// <summary>
        /// Registers one property with the base driver framework and seeds its
        /// default value. NOTE: swap the body for your SDK's actual registration
        /// call if this doesn't compile as-is (e.g. Properties.Add(new
        /// PropertyDefinition(key, type){ ... })) - everything that calls into
        /// this helper does not need to change.
        /// </summary>
        private void RegisterProperty(string key, DevicePropertyType type, object defaultValue)
        {
            SetDriverPropertyValue(key, defaultValue);
        }

        // ---------------------------------------------------------------
        // Installer-entered shade names (Curtain_1_Name .. Curtain_10_Name
        // user attributes, set in Crestron Home before the device connects)
        // ---------------------------------------------------------------

        protected override void Protocol_OnSetUserAttribute(string parameterId, string value)
        {
            foreach (var n in ShadesConstants.AllShadeNumbers())
            {
                if (parameterId != ShadesConstants.NameUserAttribute(n)) continue;

                SetDriverPropertyValue(ShadesConstants.NameProperty(n), value ?? string.Empty);
                SetDriverPropertyValue(ShadesConstants.VisibleProperty(n), !string.IsNullOrEmpty(value));
                return;
            }
        }

        // ---------------------------------------------------------------
        // Commands from the UI (Open / Stop / Close buttons -> command:shadeNopen etc.)
        // ---------------------------------------------------------------

        public override void DoCommand(string command, string[] parameters)
        {
            if (!ShadesConstants.TryParseCommand(command, out var shadeNumber, out var action))
            {
                ErrorLog($"Shades.DoCommand: unrecognized command '{command}'");
                return;
            }

            switch (action)
            {
                case "open":
                    _protocol.OpenShade(shadeNumber);
                    break;
                case "stop":
                    _protocol.StopShade(shadeNumber);
                    break;
                case "close":
                    _protocol.CloseShade(shadeNumber);
                    break;
            }
        }

        /// <summary>Lightweight error logging wrapper. NOTE: point this at your SDK's
        /// actual logging call (the reference package used a method literally named
        /// "ErrorLog") if the signature differs.</summary>
        private void ErrorLog(string message)
        {
            CrestronConsole.PrintLine($"[Shades] {message}");
        }

        // ---------------------------------------------------------------
        // SIMPL-facing events. MemberNames below must match
        // programming/Shades.json exactly - do not rename without regenerating
        // that file to match.
        // ---------------------------------------------------------------

        [ProgrammableEvent("Curtain_1_Open")]
        public event EventHandler Curtain_1_Open;

        [ProgrammableEvent("Curtain_1_Stop")]
        public event EventHandler Curtain_1_Stop;

        [ProgrammableEvent("Curtain_1_Close")]
        public event EventHandler Curtain_1_Close;

        [ProgrammableEvent("Curtain_2_Open")]
        public event EventHandler Curtain_2_Open;

        [ProgrammableEvent("Curtain_2_Stop")]
        public event EventHandler Curtain_2_Stop;

        [ProgrammableEvent("Curtain_2_Close")]
        public event EventHandler Curtain_2_Close;

        [ProgrammableEvent("Curtain_3_Open")]
        public event EventHandler Curtain_3_Open;

        [ProgrammableEvent("Curtain_3_Stop")]
        public event EventHandler Curtain_3_Stop;

        [ProgrammableEvent("Curtain_3_Close")]
        public event EventHandler Curtain_3_Close;

        [ProgrammableEvent("Curtain_4_Open")]
        public event EventHandler Curtain_4_Open;

        [ProgrammableEvent("Curtain_4_Stop")]
        public event EventHandler Curtain_4_Stop;

        [ProgrammableEvent("Curtain_4_Close")]
        public event EventHandler Curtain_4_Close;

        [ProgrammableEvent("Curtain_5_Open")]
        public event EventHandler Curtain_5_Open;

        [ProgrammableEvent("Curtain_5_Stop")]
        public event EventHandler Curtain_5_Stop;

        [ProgrammableEvent("Curtain_5_Close")]
        public event EventHandler Curtain_5_Close;

        [ProgrammableEvent("Curtain_6_Open")]
        public event EventHandler Curtain_6_Open;

        [ProgrammableEvent("Curtain_6_Stop")]
        public event EventHandler Curtain_6_Stop;

        [ProgrammableEvent("Curtain_6_Close")]
        public event EventHandler Curtain_6_Close;

        [ProgrammableEvent("Curtain_7_Open")]
        public event EventHandler Curtain_7_Open;

        [ProgrammableEvent("Curtain_7_Stop")]
        public event EventHandler Curtain_7_Stop;

        [ProgrammableEvent("Curtain_7_Close")]
        public event EventHandler Curtain_7_Close;

        [ProgrammableEvent("Curtain_8_Open")]
        public event EventHandler Curtain_8_Open;

        [ProgrammableEvent("Curtain_8_Stop")]
        public event EventHandler Curtain_8_Stop;

        [ProgrammableEvent("Curtain_8_Close")]
        public event EventHandler Curtain_8_Close;

        [ProgrammableEvent("Curtain_9_Open")]
        public event EventHandler Curtain_9_Open;

        [ProgrammableEvent("Curtain_9_Stop")]
        public event EventHandler Curtain_9_Stop;

        [ProgrammableEvent("Curtain_9_Close")]
        public event EventHandler Curtain_9_Close;

        [ProgrammableEvent("Curtain_10_Open")]
        public event EventHandler Curtain_10_Open;

        [ProgrammableEvent("Curtain_10_Stop")]
        public event EventHandler Curtain_10_Stop;

        [ProgrammableEvent("Curtain_10_Close")]
        public event EventHandler Curtain_10_Close;

        /// <summary>Called by ShadesProtocol once a command has been (or in the
        /// current stub, is assumed to have been) carried out, so the matching
        /// SIMPL event fires.</summary>
        internal void RaiseShadeEvent(int shadeNumber, string action)
        {
            switch (shadeNumber)
            {
                case 1:
                    switch (action)
                    {
                        case "open": RaiseCurtain_1_Open(); break;
                        case "stop": RaiseCurtain_1_Stop(); break;
                        case "close": RaiseCurtain_1_Close(); break;
                    }
                    break;
                case 2:
                    switch (action)
                    {
                        case "open": RaiseCurtain_2_Open(); break;
                        case "stop": RaiseCurtain_2_Stop(); break;
                        case "close": RaiseCurtain_2_Close(); break;
                    }
                    break;
                case 3:
                    switch (action)
                    {
                        case "open": RaiseCurtain_3_Open(); break;
                        case "stop": RaiseCurtain_3_Stop(); break;
                        case "close": RaiseCurtain_3_Close(); break;
                    }
                    break;
                case 4:
                    switch (action)
                    {
                        case "open": RaiseCurtain_4_Open(); break;
                        case "stop": RaiseCurtain_4_Stop(); break;
                        case "close": RaiseCurtain_4_Close(); break;
                    }
                    break;
                case 5:
                    switch (action)
                    {
                        case "open": RaiseCurtain_5_Open(); break;
                        case "stop": RaiseCurtain_5_Stop(); break;
                        case "close": RaiseCurtain_5_Close(); break;
                    }
                    break;
                case 6:
                    switch (action)
                    {
                        case "open": RaiseCurtain_6_Open(); break;
                        case "stop": RaiseCurtain_6_Stop(); break;
                        case "close": RaiseCurtain_6_Close(); break;
                    }
                    break;
                case 7:
                    switch (action)
                    {
                        case "open": RaiseCurtain_7_Open(); break;
                        case "stop": RaiseCurtain_7_Stop(); break;
                        case "close": RaiseCurtain_7_Close(); break;
                    }
                    break;
                case 8:
                    switch (action)
                    {
                        case "open": RaiseCurtain_8_Open(); break;
                        case "stop": RaiseCurtain_8_Stop(); break;
                        case "close": RaiseCurtain_8_Close(); break;
                    }
                    break;
                case 9:
                    switch (action)
                    {
                        case "open": RaiseCurtain_9_Open(); break;
                        case "stop": RaiseCurtain_9_Stop(); break;
                        case "close": RaiseCurtain_9_Close(); break;
                    }
                    break;
                case 10:
                    switch (action)
                    {
                        case "open": RaiseCurtain_10_Open(); break;
                        case "stop": RaiseCurtain_10_Stop(); break;
                        case "close": RaiseCurtain_10_Close(); break;
                    }
                    break;
            }
        }

        internal void RaiseCurtain_1_Open() => Curtain_1_Open?.Invoke(this, EventArgs.Empty);
        internal void RaiseCurtain_1_Stop() => Curtain_1_Stop?.Invoke(this, EventArgs.Empty);
        internal void RaiseCurtain_1_Close() => Curtain_1_Close?.Invoke(this, EventArgs.Empty);
        internal void RaiseCurtain_2_Open() => Curtain_2_Open?.Invoke(this, EventArgs.Empty);
        internal void RaiseCurtain_2_Stop() => Curtain_2_Stop?.Invoke(this, EventArgs.Empty);
        internal void RaiseCurtain_2_Close() => Curtain_2_Close?.Invoke(this, EventArgs.Empty);
        internal void RaiseCurtain_3_Open() => Curtain_3_Open?.Invoke(this, EventArgs.Empty);
        internal void RaiseCurtain_3_Stop() => Curtain_3_Stop?.Invoke(this, EventArgs.Empty);
        internal void RaiseCurtain_3_Close() => Curtain_3_Close?.Invoke(this, EventArgs.Empty);
        internal void RaiseCurtain_4_Open() => Curtain_4_Open?.Invoke(this, EventArgs.Empty);
        internal void RaiseCurtain_4_Stop() => Curtain_4_Stop?.Invoke(this, EventArgs.Empty);
        internal void RaiseCurtain_4_Close() => Curtain_4_Close?.Invoke(this, EventArgs.Empty);
        internal void RaiseCurtain_5_Open() => Curtain_5_Open?.Invoke(this, EventArgs.Empty);
        internal void RaiseCurtain_5_Stop() => Curtain_5_Stop?.Invoke(this, EventArgs.Empty);
        internal void RaiseCurtain_5_Close() => Curtain_5_Close?.Invoke(this, EventArgs.Empty);
        internal void RaiseCurtain_6_Open() => Curtain_6_Open?.Invoke(this, EventArgs.Empty);
        internal void RaiseCurtain_6_Stop() => Curtain_6_Stop?.Invoke(this, EventArgs.Empty);
        internal void RaiseCurtain_6_Close() => Curtain_6_Close?.Invoke(this, EventArgs.Empty);
        internal void RaiseCurtain_7_Open() => Curtain_7_Open?.Invoke(this, EventArgs.Empty);
        internal void RaiseCurtain_7_Stop() => Curtain_7_Stop?.Invoke(this, EventArgs.Empty);
        internal void RaiseCurtain_7_Close() => Curtain_7_Close?.Invoke(this, EventArgs.Empty);
        internal void RaiseCurtain_8_Open() => Curtain_8_Open?.Invoke(this, EventArgs.Empty);
        internal void RaiseCurtain_8_Stop() => Curtain_8_Stop?.Invoke(this, EventArgs.Empty);
        internal void RaiseCurtain_8_Close() => Curtain_8_Close?.Invoke(this, EventArgs.Empty);
        internal void RaiseCurtain_9_Open() => Curtain_9_Open?.Invoke(this, EventArgs.Empty);
        internal void RaiseCurtain_9_Stop() => Curtain_9_Stop?.Invoke(this, EventArgs.Empty);
        internal void RaiseCurtain_9_Close() => Curtain_9_Close?.Invoke(this, EventArgs.Empty);
        internal void RaiseCurtain_10_Open() => Curtain_10_Open?.Invoke(this, EventArgs.Empty);
        internal void RaiseCurtain_10_Stop() => Curtain_10_Stop?.Invoke(this, EventArgs.Empty);
        internal void RaiseCurtain_10_Close() => Curtain_10_Close?.Invoke(this, EventArgs.Empty);
    }
}
