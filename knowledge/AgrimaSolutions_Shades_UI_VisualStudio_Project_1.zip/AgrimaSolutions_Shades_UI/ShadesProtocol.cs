using Crestron.RAD.Common.BasicDriver;

namespace UI_Tiles_AgrimaSolutions_Shades_Generic_UI_Cloud_Connected
{
    /// <summary>
    /// Translates high-level shade requests (open/stop/close on a given shade number)
    /// into transport calls, and reports results back to the owning device so the
    /// matching SIMPL event can fire.
    ///
    /// BUILD NOTE: extends ABaseDriverProtocol to match the reference architecture -
    /// confirm the exact base member list against IntelliSense once this is opened in
    /// Visual Studio with the real Crestron.RAD.Common package installed.
    /// </summary>
    internal class ShadesProtocol : ABaseDriverProtocol
    {
        private readonly Shades _device;
        private readonly ShadesTransport _transport;

        public ShadesProtocol(Shades device)
        {
            _device = device;
            _transport = new ShadesTransport();
        }

        public void Initialize()
        {
            _transport.Connect();
        }

        public void OpenShade(int shadeNumber) => Execute(shadeNumber, "open");
        public void StopShade(int shadeNumber) => Execute(shadeNumber, "stop");
        public void CloseShade(int shadeNumber) => Execute(shadeNumber, "close");

        private void Execute(int shadeNumber, string action)
        {
            // ShadesTransport.SendCommand is currently a stub (no vendor cloud API
            // wired up yet - see ShadesTransport.cs). It always reports success so the
            // driver is fully testable end-to-end (UI -> DoCommand -> here -> SIMPL
            // event) before a real cloud integration exists.
            //
            // Once a real API is wired up, this should NOT assume success here -
            // instead, only call _device.RaiseShadeEvent(...) once the transport
            // confirms the command actually completed (e.g. from the cloud service's
            // response or a status-poll callback), and surface failures via ErrorLog
            // instead of silently raising the event.
            var succeeded = _transport.SendCommand(shadeNumber, action);

            if (succeeded)
            {
                _device.RaiseShadeEvent(shadeNumber, action);
            }
        }
    }
}
