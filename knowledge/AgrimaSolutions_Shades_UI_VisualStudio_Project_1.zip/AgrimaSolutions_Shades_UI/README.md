# Agrima Solutions – Shades UI (Cloud Connected)

Original driver, built from scratch — no Cavitak code anywhere. Same functional
shape as the reference package it replaces: up to 10 independently-controlled
shades/curtains, Open/Stop/Close per shade, installer names each shade before
it connects.

## Open this in Visual Studio

1. Open the `.csproj` in Visual Studio (same machine/setup you used for the
   Fan Controller driver).
2. **Before building**, open your working Fan Controller project's package
   references and copy them into this project's `.csproj` — replace the
   placeholder `<PackageReference>` entries near the top with the exact same
   ones (DevKit / ManifestUtil / ProgramInterface / SimplSharp SDK). That
   combination is already proven to restore correctly for you; guessing at
   package names here would just cost you a NuGet restore failure.
3. Build.

## What will probably need a small fix on first build

I wrote every method against the architecture confirmed from the reference
driver (`AExtensionDevice`, `ICloudConnected`, `ABaseDriverProtocol`,
`ATransportDriver`, `Create_Device_Definition`, `SetDriverPropertyValue`,
`Protocol_OnSetUserAttribute`, `DoCommand`) — I validated the rest of the code
compiles cleanly against those exact shapes. What I *can't* verify without the
real SDK installed is whether Crestron's actual method signatures match
mine exactly. If the compiler flags a mismatch on one of those specific
calls, that's expected — send me the exact error and line, same as always,
and I'll fix the signature. The surrounding logic (the shade/property/command
handling) does not need to change.

## What's stubbed — this is the part that matters most

`ShadesTransport.cs` → `SendCommand()` doesn't talk to any real cloud service
yet. It logs what it would have sent and always reports success, so the
driver is fully testable end-to-end (tile → command → SIMPL event) before any
real integration exists. Search that file for `TODO` to find the exact spot —
once you have a target shades vendor and their API details, that's the only
method that needs real logic. Everything else (UI, properties, events,
manifest) is already complete.

## Files

| File | Purpose |
|---|---|
| `Shades.cs` | Main device class — properties, commands, SIMPL events |
| `ShadesProtocol.cs` | Translates Open/Stop/Close into transport calls |
| `ShadesTransport.cs` | **Stubbed** cloud communication layer |
| `ShadesConstants.cs` | Every property/command/event key in one place |
| `Properties/AssemblyInfo.cs` | Agrima Solutions assembly metadata |
| `UI_Tiles_AgrimaSolutions_Shades_Generic_UI_Cloud_Connected.dat` | Manifest |
| `programming/Shades.json` | SIMPL program interface (already valid, reused as-is) |
| `translations/en-US.json` | Translation strings (already valid, reused as-is) |
| `uidefinitions/UiDefinition.xml` | UI tiles/layout (already valid, reused as-is) |

The `.dat`, `programming/`, `translations/`, and `uidefinitions/` files are
already schema-validated and confirmed Cavitak-free — they're the same ones
from the earlier rebrand pass. Visual Studio's build (via ManifestUtil) may
regenerate the `.dat` and `programming/Shades.json` automatically once it can
see the compiled properties/events — if so, just confirm the regenerated
versions match this structure.

## Deploying

Same as always: FTP the built package to `\User\ThirdPartyDrivers\Import` on
the CP4-R, bump `DriverVersion` + reboot if you're overwriting a previous load
on the same processor.
