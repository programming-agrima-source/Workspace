using System.Collections.Generic;

namespace UI_Tiles_AgrimaSolutions_Shades_Generic_UI_Cloud_Connected
{
    /// <summary>
    /// Single source of truth for every string key this driver uses.
    /// The property/command names here MUST match uidefinitions/UiDefinition.xml exactly
    /// (e.g. {shade1name}, {shade1visible}, command:shade1open) - that file is already
    /// built and validated, so these helpers just generate the same strings in code
    /// instead of retyping them by hand in ten places.
    /// </summary>
    internal static class ShadesConstants
    {
        /// <summary>How many shade/curtain channels this driver exposes. Matches the
        /// Curtain_1_Name .. Curtain_10_Name user attributes and the 10 control groups
        /// in the UI definition.</summary>
        public const int ShadeCount = 10;

        public static string NameProperty(int shadeNumber) => $"shade{shadeNumber}name";
        public static string VisibleProperty(int shadeNumber) => $"shade{shadeNumber}visible";

        public static string OpenCommand(int shadeNumber) => $"shade{shadeNumber}open";
        public static string StopCommand(int shadeNumber) => $"shade{shadeNumber}stop";
        public static string CloseCommand(int shadeNumber) => $"shade{shadeNumber}close";

        /// <summary>Matches the "ParameterId" values in the .dat manifest's userAttributes
        /// array - these are set by the installer in Crestron Home before the device
        /// connects (RequiredForConnection: "Before").</summary>
        public static string NameUserAttribute(int shadeNumber) => $"Curtain_{shadeNumber}_Name";

        /// <summary>Matches the MemberName values in programming/Shades.json - these are
        /// the SIMPL-facing event names raised on each shade action. Do not rename these
        /// without regenerating programming/Shades.json to match.</summary>
        public static string OpenEvent(int shadeNumber) => $"Curtain_{shadeNumber}_Open";
        public static string StopEvent(int shadeNumber) => $"Curtain_{shadeNumber}_Stop";
        public static string CloseEvent(int shadeNumber) => $"Curtain_{shadeNumber}_Close";

        /// <summary>
        /// Parses a UI command string like "shade7open" into the shade number (7) and the
        /// action ("open"). Returns false if the string doesn't match the expected pattern.
        /// </summary>
        public static bool TryParseCommand(string command, out int shadeNumber, out string action)
        {
            shadeNumber = 0;
            action = null;

            if (string.IsNullOrEmpty(command) || !command.StartsWith("shade"))
                return false;

            var digits = new System.Text.StringBuilder();
            var i = 5; // length of "shade"
            while (i < command.Length && char.IsDigit(command[i]))
            {
                digits.Append(command[i]);
                i++;
            }

            if (digits.Length == 0 || !int.TryParse(digits.ToString(), out shadeNumber))
                return false;

            if (shadeNumber < 1 || shadeNumber > ShadeCount)
                return false;

            action = command.Substring(i); // "open" / "stop" / "close"
            return action == "open" || action == "stop" || action == "close";
        }

        /// <summary>All shade numbers 1..10, for loops that need to touch every channel.</summary>
        public static IEnumerable<int> AllShadeNumbers()
        {
            for (var i = 1; i <= ShadeCount; i++)
                yield return i;
        }
    }
}
