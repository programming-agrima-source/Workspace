using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("UI_Tiles_AgrimaSolutions_Shades_Generic_UI_Cloud_Connected")]
[assembly: AssemblyDescription("Agrima Solutions Shades UI - Cloud Connected extension driver")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Agrima Solutions")]
[assembly: AssemblyProduct("Agrima Solutions Shades UI")]
[assembly: AssemblyCopyright("Copyright © Agrima Solutions 2026")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]
[assembly: Guid("1197f31d-59a2-429f-9401-71b86f75d0e1")]

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
